/*
 * File:   Initialize.c
 * * Author: Sean, Ryeen, Aarushi
 *
 * Created on October 15, 2023, 9:08 PM
 */


#include "xc.h"

void IOinit (void)
{
    AD1PCFG = 0xFFFF;   //Turn all analog pins as digital
//    AD1PCFGbits.PCFG2 = 0; 
    //setting RA2,RA4,RB4 to inputs and RB8 to output
    TRISAbits.TRISA2 = 1;
    TRISAbits.TRISA4 = 1;
    TRISBbits.TRISB4 = 1;
    TRISBbits.TRISB8 = 0;
    //Pulls up the respective input pins
    CNPU2bits.CN30PUE =1;
    CNPU1bits.CN1PUE = 1;
    CNPU1bits.CN0PUE =1;
    //enable CN interrupts on respective pins
    CNEN1bits.CN0IE = 1;
    CNEN1bits.CN1IE = 1;
    CNEN2bits.CN30IE = 1;
    //setup CN interrupt
    IPC4bits.CNIP = 5;
    IFS1bits.CNIF = 0;
    IEC1bits.CNIE = 1;
    
    
    
    return;
}

void TMRinit (void)
{
    //T2CON config
    T2CONbits.T32 = 0; // operate timer 2 as 16 bit timer
    T2CONbits.TCKPS = 2; // set prescaler to 64
    T2CONbits.TCS = 0; // use internal clock
    T2CONbits.TSIDL = 0; //operate in idle mode
    // Timer 2 interrupt config
    IPC1bits.T2IP = 4; //7 is highest and 1 is lowest pri.
    IFS0bits.T2IF = 0;
    IEC0bits.T2IE = 1; //enable timer interrupt
    
    
    //T1CON config
    T1CONbits.TCKPS = 2; // set prescaler to 64
    T1CONbits.TCS = 0; // use internal clock
    T1CONbits.TSIDL = 0; //operate in idle mode
    // Timer 1 interrupt config
    IPC0bits.T1IP = 3; //7 is highest and 1 is lowest pri.
    IFS0bits.T1IF = 0;
    IEC0bits.T1IE = 1; //enable timer interrupt
    return;
}