/*
 * File:   newmainXC16.c
 * Author: Sean, Ryeen, Aarushi
 *
 * Created on September 28, 2023, 8:11 AM
 */

// PIC24F16KA101 Configuration Bit Settings

// FOSCSEL
#pragma config FNOSC = FRCDIV           // Oscillator Select (8 MHz FRC oscillator with divide-by-N (FRCDIV))
#pragma config IESO = ON                // Internal External Switch Over bit (Internal External Switchover mode enabled (Two-Speed Start-up enabled))

// FOSC
#pragma config POSCMOD = NONE           // Primary Oscillator Configuration bits (Primary oscillator disabled)
#pragma config OSCIOFNC = OFF           // CLKO Enable Configuration bit (CLKO output signal is active on the OSCO pin)
#pragma config POSCFREQ = HS            // Primary Oscillator Frequency Range Configuration bits (Primary oscillator/external clock input frequency greater than 8 MHz)
#pragma config SOSCSEL = SOSCHP         // SOSC Power Selection Configuration bits (Secondary oscillator configured for high-power operation)
#pragma config FCKSM = CSECMD           // Clock Switching and Monitor Selection (Clock switching is enabled, Fail-Safe Clock Monitor is disabled)
#pragma config ICS = PGx2               // ICD Pin Placement Select bits (PGC2/PGD2 are used for programming and debugging the device)

#include <xc.h>
#include "clkChange.h"

#define LED_ON LATBbits.LATB8=1
#define LED_OFF LATBbits.LATB8=0
#define LED_BLINK LATBbits.LATB8^=1

#define PB1 PORTAbits.RA2
#define PB2 PORTAbits.RA4
#define PB3 PORTBbits.RB4

#define FAST_IDLE 0
#define FAST_PB1 1
#define FAST_PB2 2
#define FAST_PB3 3
#define FAST_2PB  4
#define SLOW_IDLE 5
#define SLOW_PB1 6
#define SLOW_PB2 7

uint8_t state=FAST_IDLE;                      //Start in Idle
uint8_t count=3;                              //Multiple button push
uint8_t CNflag=0;                             //CN interrupt flag
uint8_t p1=1;                                 //PB1
uint8_t p2=1;                                 //PB2
uint8_t p3=1;                                 //PB3
uint8_t first=1;                              //Used to determine first time in loop

int main(void) {
    
    IOinit();      //IO initialize 
    
    TMRinit();     //Timer initialize
    
    InitUART2();   //UART initialize
    
    newClk(500);   //Clock Change
    
    while(1){
        while (state==FAST_IDLE){              //fast idle
            LED_OFF;
            T1CONbits.TON=0;                   //Turn blinking timer off
            if(first==1){
                Disp2String("Fast Mode: IDLE\n\r"); 
                first=0;                       //clears first since it is no longer the first cycle
            }
            Idle();                            //Wait for interrupt
            IOcheck();                         //Check IO
            if(count==0){
                first=1;
                state=SLOW_IDLE;
            }
            else if(count==1){
                first=1;
                state=FAST_2PB;
            }
            else if(p1==0){
                first=1;
                Disp2String("Fast Mode: PB1 was pressed\n\r");
                state=FAST_PB1;
            }
            else if(p2==0){
                first=1;
                Disp2String("Fast Mode: PB2 was pressed\n\r");
                state=FAST_PB2;
            }
            else if(p3==0){
                first=1;
                Disp2String("Fast Mode: PB3 was pressed\n\r");
                state=FAST_PB3;
            }
        }
        while(state==FAST_PB1){              //fast PB1 pressed
            if(first==1){                    //makes initial press turn LED on
                LED_BLINK;
                first=0;
            }
            delay_ms3(250);
            Idle();                          //Wait for interrupt
            if(CNflag==1){
                CNflag=0;                    //clear flag
                IOcheck();                   //Update IO read
                if(p1==0){                   //check for PB1
                    first=1;                 //Makes it so the first if statement is read again in fast Idle
                    state=FAST_IDLE;         //switch states
                }
            }
        }
        while(state==FAST_PB2){               //fast PB2 pressed
            if(first==1){                     //makes initial press turn LED on
                LED_BLINK;
                first=0;
            }
            delay_ms3(500);
            Idle();                           //Wait for interrupt
            if(CNflag==1){
                CNflag=0;                    //clear flag
                IOcheck();                   //Update IO read   
                if(p2==0){                   //check for PB2
                    first=1;                 //Makes it so the first if statement is read again in fast Idle
                    state=FAST_IDLE;         //switch states
                }
            }
        } 
        while(state==FAST_PB3){               //fast PB3 pressed
            if(first==1){                     //makes initial press turn LED on
                LED_BLINK;
                first=0;
            }
            delay_ms3(1000);
            Idle();                           //Wait for interrupt
            if(CNflag==1){
                CNflag=0;                     //clear flag
                IOcheck();                    //Update IO read  
                if(p3==0){                    //check for PB3
                    first=1;                  //Makes it so the first if statement is read again in fast Idle
                    state=FAST_IDLE;          //switch states
                }
            }
        }
        while(state==FAST_2PB){               //fast 2 PB pressed
            LED_ON;
            if(first==1){
                if(p1==0 && p2==0){
                    Disp2String("Fast Mode: PB1 and PB2 was pressed\n\r");  
                }else if(p1==0 && p3==0){
                    Disp2String("Fast Mode: PB1 and PB3 was pressed\n\r");
                }else{
                    Disp2String("Fast Mode: PB2 and PB3 was pressed\n\r");
                }
            }
            if(first==1){                    //clears flag to make sure it doesnt run through next if statement
                CNflag=0;
            }
            first=0;
            Idle();                          //Wait for interrupt
            if(CNflag==1){
                CNflag=0;                    //clear flag
                IOcheck();                   //Update IO read 
                if(p1==0||p2==0||p3==0){     //check for all PB press
                    first=1;                 //Makes it so the first if statement is read again in fast Idle
                    state=FAST_IDLE;         //switch states
                } 
           }
        }
        while(state==SLOW_IDLE){               //slow idle
            LED_OFF;  
            T1CONbits.TON=0;                  //Turn blinking timer off
            Idle();                           //Wait for interrupt
            if(first==1){
                Disp2String("Slow Mode: IDLE\n\r");
                first=0;                      //clears first since it is no longer the first cycle
            }
            IOcheck();                        //check IO
            if(count==0){
                first=1;
                state=FAST_IDLE;
            }
            else if(count==1){
                state=SLOW_IDLE;
            }
            else if(p1==0){
                first=1;
                Disp2String("Slow Mode: PB1 was pressed\n\r");
                state=SLOW_PB1;
            }
            else if(p2==0){
                first=1;
                Disp2String("Slow Mode: PB2 was pressed\n\r");
                state=SLOW_PB2;
            }
        }
        while(state==SLOW_PB1){               //slow PB1 pressed
            if(first==1){                     //makes initial press turn LED on
                LED_BLINK;
                first=0;
            }
            delay_ms3(5000);
            Idle();                          //Wait for interrupt
            if(CNflag==1){
                CNflag=0;                    //clear flag
                IOcheck();                   //Update IO read  
                if(p1==0){                   //Check for PB1
                    first=1;                 //Makes it so the first if statement is read again in slow Idle
                    state=SLOW_IDLE;
                }
            }
        }
        while(state==SLOW_PB2){              //slow PB2 pressed
            if(first==1){                    //makes initial press turn LED on
                LED_BLINK;
                first=0;
            }
            delay_ms3(3000);
            Idle();                         //Wait for interrupt
            if(CNflag==1){
                CNflag=0;                   //clear flag
                IOcheck();                  //Update IO read        
                if(p2==0){                  //Check for PB2
                    first=1;                //Makes it so the first if statement is read again in slow Idle
                    state=SLOW_IDLE;
                }
            }
        }
    }
    return 0;
}

void IOcheck(void) {
    //read all values
    delay_ms2(50);                        //delay that cant be interrupted by PB press for proper de-bounce
    p1=PB1;
    p2=PB2;
    p3=PB3;
    
    count=p1+p2+p3;                      //Used to see if multiple push buttons are pressed
}

void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void){
    IFS0bits.T2IF=0;              //clears the  flag
    T2CONbits.TON=0;              //Turns off timer
}

void __attribute__((interrupt, no_auto_psv)) _T1Interrupt(void){ //blinks LED and keeps running until code returns to idle mode
    LED_BLINK;
    IFS0bits.T1IF=0;              //clears the  flag
}

void delay_ms2(unsigned int (time_ms)){                         //delay to make sure CN interrupt doesnt interfere
    IEC1bits.CNIE = 0;
    TMR2=0;                      //resets timer
    PR2= time_ms *(4);           //(500000/(2*64*1000))=3.9025~=4
    T2CONbits.TON=1;             //Turns on timer
    Idle();                      //makes main wait for TMR1==PR1 
    IEC1bits.CNIE = 1;
    return;
}

void delay_ms3(unsigned int (time_ms)){                         //delay to make LED blink while not being interrupted until return to idle mode
    TMR1=0;                      //resets timer
    PR1= time_ms *(4);           //(500000/(2*64*1000))=3.9025~=4
    T1CONbits.TON=1;             //Turns on timer       
    return;
}

void __attribute__((interrupt, no_auto_psv)) _CNInterrupt(void)
{   
    if(PB1==0||PB2==0||PB3==0){                               //any press of a button will set the flag
        CNflag=1;
    }
    IFS1bits.CNIF = 0; // clear IF flag
    return;
}