/*
 * File:   Initialize.c
 * * Author: Sean, Ryeen, Aarushi
 *
 * Created on October 15, 2023, 9:08 PM
 */


#include "xc.h"

void IOinit (void)
{
    AD1PCFG=0xffff;      //sets all pins to digital
    AD1PCFGbits.PCFG5=0; //sets pin8 to analog
    AD1CSSLbits.CSSL5=0; //analog channel omitted from input scan
    TRISAbits.TRISA3=1;  //sets RA3 to input
    
    return;
}

void TMRinit (void)
{
    //T2CON config
    T2CONbits.T32 = 0; // operate timer 2 as 16 bit timer
    T2CONbits.TCKPS = 2; // set prescaler to 64
    T2CONbits.TCS = 0; // use internal clock
    T2CONbits.TSIDL = 0; //operate in idle mode
    // Timer 2 interrupt config
    IPC1bits.T2IP = 4; //7 is highest and 1 is lowest pri.
    IFS0bits.T2IF = 0;
    IEC0bits.T2IE = 1; //enable timer interrupt
}

