/*
 * File:   main.c
 * Author: Sean, Ryeen, Aarushi
 *
 * Created on November 2, 2023, 9:26 AM
 */

// PIC24F16KA101 Configuration Bit Settings

/*
 * I recommend adding the FWDTEN setting to OFF pragma, as this stops your microcontroller periodically resetting itself when nothing happens
 */
#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))

// FOSCSEL
#pragma config FNOSC = FRCDIV           // Oscillator Select (8 MHz FRC oscillator with divide-by-N (FRCDIV))
#pragma config IESO = ON                // Internal External Switch Over bit (Internal External Switchover mode enabled (Two-Speed Start-up enabled))

// FOSC
#pragma config POSCMOD = NONE           // Primary Oscillator Configuration bits (Primary oscillator disabled)
#pragma config OSCIOFNC = OFF           // CLKO Enable Configuration bit (CLKO output signal is active on the OSCO pin)
#pragma config POSCFREQ = HS            // Primary Oscillator Frequency Range Configuration bits (Primary oscillator/external clock input frequency greater than 8 MHz)
#pragma config SOSCSEL = SOSCHP         // SOSC Power Selection Configuration bits (Secondary oscillator configured for high-power operation)
/*
 * Adding the FCKSM = CSECMD enables clock switching
 */
#pragma config FCKSM = CSECMD           // Clock Switching and Monitor Selection (Clock switching is enabled, Fail-Safe Clock Monitor is disabled)
/*
 * This pragma enables using the stepping debugger/setting breakpoints on the microcontroller
 */
#pragma config ICS = PGx2               // ICD Pin Placement Select bits (PGC2/PGD2 are used for programming and debugging the device)

#include <xc.h>
#include "clkChange.h"
#include "uart.h"
#include "ADC.h"

#define Decimal 0
#define Hex 1

extern uint8_t RXFlag;

uint16_t ADC= 0;
uint8_t state=Decimal;
uint8_t receive_char = 0;
uint8_t T2Flag=0;

int main(void) {
    
    newClk(500);   //Sets clock to 500kHz
    
    IOinit();      //IO initialize 
    
    InitUART2();   //Uart initialize
       
    TMRinit();     //Timer initialize
    
    while(1) {
        delay_ms(50);                   //activates the timer to make the ADC trigger periodically
        while(state==Decimal){
            if(T2Flag==1){               //waits for timer to finish then activates ADC
                ADC=do_ADC();            //gets the ADC output
                T2Flag=0;                //clears flag
            }
            BarGraphDec(ADC);            //display bar graph
            if(RXFlag==1){               //checks for new input
                if(RecvUartChar()=='x')  //waits for enter key and sees if it is 'x'
                {
                    state=Hex;           //switch states
                }
                Disp2String("\r");   //returns to start of line
                RXFlag=0;                //clears flag
            }
        }
        while(state==Hex){
            if(T2Flag==1){               //waits for timer to finish then activates ADC
                ADC=do_ADC();            //gets the ADC output
                T2Flag=0;                //clears flag
            }
            BarGraphHex(ADC);            //display bar graph
            if(RXFlag==1){               //checks for new input
                if(RecvUartChar()=='d')  //waits for enter key and sees if it is 'x'
                {
                    state=Decimal;       //switch states
                }
                RXFlag=0;                //clears flag
                Disp2String("\r");   //returns to start of line
            }
        }
    }
    return 0;
}

void BarGraphDec(uint16_t ADC_int) //Decimal bar graph function
{
    uint16_t len = 50;             //bar is a 50 characters long

    uint16_t len_bar = ADC_int * len / 1024; //takes the ratio of the ADC output to the ADC max value and then finds out how many '-' long it will be
    
    XmitUART2('-', len_bar);       //Width of bar
    XmitUART2('_', len - len_bar); //fills the remaining line with '_' to show blank
    Disp2Dec(ADC);                 //adds Decimal value at the end of the bar
    Disp2String("\r");             //return to start of line

    return;
}

void BarGraphHex(uint16_t ADC_int) //Hex bar graph function
{
    uint16_t len = 50;             //bar is a 50 characters long

    uint16_t len_bar = ADC_int * len / 1024; //takes the ratio of the ADC output to the ADC max value and then finds out how many '-' long it will be
    
    XmitUART2('-', len_bar);       //Width of bar
    XmitUART2('_', len - len_bar); //fills the remaining line with '_' to show blank
    Disp2Hex(ADC);                 //adds Hex value at the end of the bar
    Disp2String("\r");             //return to start of line

    return;
}

void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void){
    IFS0bits.T2IF=0;             //clears the  flag
    T2Flag=1;                    //sets global flag to be used in main code(activates ADC)
}

void delay_ms(unsigned int (time_ms)){
    TMR2=0;                      //resets timer
    PR2= time_ms *(4);           //(500000/(2*64*1000))=3.9025~=4
    T2CONbits.TON=1;             //Turns on timer
    return;
}
