/*
 * File:   Delays.c
 * Author: Sean
 *
 * Created on December 1, 2023, 12:10 PM
 */


#include "xc.h"
#include "Delays.h"

#define error 6
#define unlocked 5
#define special_timer 8
#define special_reset_timer 9
#define special_toggle 10

extern uint8_t error_msg;
extern uint8_t state;
extern uint8_t CNflag;
extern uint8_t seconds;
extern uint8_t toggle;
uint8_t T1Flag=0;                //Timer 1 flag
uint8_t T2Flag=0;                //5 Second unlock timer flag
uint8_t count=0;                 //keeps track of how many LED blinks
uint8_t reset=0;                 //used in special state for when the timer should be reset

void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void){
    IFS0bits.T2IF=0; //clears the  flag
    if(state==special_reset_timer||state==special_timer||state==special_toggle){ //for the special state
        seconds++;
    }else if(state!=unlocked){       //for locked states excluding the unlocked state
        LATBbits.LATB8^=1;           //blinks LED
        if(count==100){              //if it blinks 50 times send to the error state. One blink is one on off hence 100 times and not 50
            state=error;             //send to error state
            error_msg=2;             //error message for timed out
            CNflag=1;                //turns on flag to break out of the uart functions
        }
        count++; 
    }else{                           //for 5 second timer in unlock state
        T2Flag=1;                    //turns on flag signaling 5 seconds have been reached
        T2CONbits.TON=0;             //turn off timer
    }
}

void __attribute__((interrupt, no_auto_psv)) _T1Interrupt(void){
    IFS0bits.T1IF=0;             //clears the  flag
    T1Flag=1;                    //sets global flag to be used in main code(activates ADC)
    
}
void __attribute__((interrupt, no_auto_psv)) _T3Interrupt(void){
    IFS0bits.T3IF=0;             //clears the  flag
    T3CONbits.TON=0;             //turns off timer
    reset=1;                     //used in the special state
}

void delay_ADC(unsigned int (time_ms)){   //delay for ADC
    TMR1=0;                      //resets timer
    PR1= time_ms *(4);           //(500000/(2*64*1000))=3.9025~=4
    T1CONbits.TON=1;             //Turns on timer
    return;
}

void delay_misc(unsigned int (time_ms)){ //delay for special mode seconds, locked blink and 5 second unlock. no idle to make this run when the other code is running
    TMR2=0;                      //resets timer
    PR2= time_ms *(4);           //(500000/(2*64*1000))=3.9025~=4
    T2CONbits.TON=1;             //Turns on timer
    return;
}

void delay_ms(unsigned int (time_ms)){  //delay for IO check and 5 second reset in special mode
    TMR3=0;                      //resets timer
    PR3= time_ms *(4);           //(500000/(2*64*1000))=3.9025~=4
    T3CONbits.TON=1;             //Turns on timer
    Idle();                      //waits for interrupt
    return;
}