/*
 * File:   ADC.c
 * Author: Sean, Ryeen, Aarushi
 *
 * Created on November 23, 2023, 10:45 PM
 */


#include "xc.h"
#include "ADC.h"
uint16_t do_ADC(void)
{
    /* ------------- ADC INITIALIZATION ------------------*/
    uint16_t ADCvalue;  //16 bit register used to hold ADC1BUF0
    AD1CON1bits.SSRC = 0b111; //auto convert
    AD1CON1bits.FORM = 0b00;  //stores data at integer
    AD1CON2bits.VCFG = 0b000; //Selects AVDD, AVSS as Vref
    AD1CON1bits.ASAM = 0;     //sample when SAMP bit is set
    AD1CON2bits.CSCNA = 0;    //does not scan inputs
    AD1CON2bits.BUFM =0;      //16 word buffer
    AD1CON2bits.ALTS =0;      //uses MUX A
    AD1CON3bits.SAMC=0b11111; //using slowest sampling time 31*2/fclk to save power
    AD1CHSbits.CH0NA=0;       //channel 0 negative inputs is VR-
    AD1CHSbits.CH0SA=0b0101;  //channel o positive input is AN5
    AD1CON3bits.ADRC = 0;     // Use system clock
    AD1CON3bits.ADCS = 0b11111;

    /* ------------- ADC SAMPLING AND CONVERSION ------------------*/
    AD1CON1bits.ADON = 1; // turn on ADC module
    AD1CON1bits.SAMP=1; //Start Sampling, Conversion starts automatically after SSRC and SAMC settings
    while(AD1CON1bits.DONE==0) //waits for the conversion to finish
    {}
    ADCvalue = ADC1BUF0; //store ADC output into variable
    AD1CON1bits.SAMP=0; //Stop sampling
    AD1CON1bits.ADON=0; //Turn off ADC, ADC value stored in ADC1BUF0;
    return (ADCvalue); //returns 10 bit ADC output stored in ADC1BIF0 to calling function
}

