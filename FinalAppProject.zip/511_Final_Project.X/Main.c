/*
 * File:   main.c
 * Author: Sean, Ryeen, Aarushi
 *
 * Created on November 2, 2023, 9:26 AM
 */

// PIC24F16KA101 Configuration Bit Settings

#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))

// FOSCSEL
#pragma config FNOSC = FRCDIV           // Oscillator Select (8 MHz FRC oscillator with divide-by-N (FRCDIV))
#pragma config IESO = ON                // Internal External Switch Over bit (Internal External Switchover mode enabled (Two-Speed Start-up enabled))

// FOSC
#pragma config POSCMOD = NONE           // Primary Oscillator Configuration bits (Primary oscillator disabled)
#pragma config OSCIOFNC = ON            // CLKO Enable Configuration bit (CLKO output signal is active on the OSCO pin)
#pragma config POSCFREQ = HS            // Primary Oscillator Frequency Range Configuration bits (Primary oscillator/external clock input frequency greater than 8 MHz)
#pragma config SOSCSEL = SOSCHP         // SOSC Power Selection Configuration bits (Secondary oscillator configured for high-power operation)
/*
 * Adding the FCKSM = CSECMD enables clock switching
 */
#pragma config FCKSM = CSECMD           // Clock Switching and Monitor Selection (Clock switching is enabled, Fail-Safe Clock Monitor is disabled)
/*
 * This pragma enables using the stepping debugger/setting breakpoints on the microcontroller
 */
#pragma config ICS = PGx2               // ICD Pin Placement Select bits (PGC2/PGD2 are used for programming and debugging the device)

#include <xc.h>
#include "clkChange.h"
#include "uart.h"
#include "ADC.h"
#include "Delays.h"
//external flags and variables
extern uint8_t RXFlag;            //Rx flag
extern uint8_t count;
extern uint8_t T1Flag;
extern uint8_t T2Flag;
extern uint8_t reset;

#define BUF_SIZE 4
//states
#define first_char 1
#define second_char 2
#define third_char 3
#define fourth_char 4
#define unlocked 5
#define error 6
#define special 7
#define special_timer 8
#define special_reset_timer 9
#define special_toggle 10
//read defines
#define PB1 PORTAbits.RA2
#define PB2 PORTBbits.RB4
#define PB3 PORTAbits.RA4
//global variables
uint8_t state=first_char;          //sets state to initial lock state
uint16_t CNflag=0;                 //PB1 flag
uint8_t CNflag2=0;                 //PB2 flag
uint8_t CNflag3=0;                 //PB3 flag
uint8_t error_msg;                 //used to determine which error message to display
uint16_t ADC=0;                    //variable to store ADC output
uint16_t len_bar;                  //keeps track of how long the bar graph is
uint8_t toggle=0;                  //used to toggle the timer pause and start in special state
uint8_t ADC_timer_val=0;           //used for max value of special timer on enter

uint8_t p1=1;                      //PB1
uint8_t p2=1;                      //PB2
uint8_t p3=1;                      //PB3

//special variables
uint8_t seconds=0;                 // counts seconds on timer
uint8_t start_pause=1;             // Toggles for start/pause function when PB1 pressed

char receive_buffer[BUF_SIZE];     //used for RecvUart
//password
char password[3]={'a','b','c'};    //password for first 3 characters
uint8_t ADCpassword =3;            //password for ADC(fourth character)

int main(void) {

    newClk(500);     //500kHz clock

    InitUART2();

    IOinit();

    TMRinit();

    while(1)
    {
        switch(state){
            /*Initial and beginning of lock state. resets most variables and turns off timers that could be left on from other states
             *depending on when the state was broken out from*/
            case first_char:
                //all resets to ensure nothing was missed when returning back to first state
                count=0;
                RXFlag=0;
                CNflag=0;
                T2Flag=0;
                seconds=0;
                T1CONbits.TON=0;
                T2CONbits.TON=0;
                T3CONbits.TON=0;
                Disp2String("\rWelcome! Enter 1st character\n\r");
                LATBbits.LATB8=1;                     //sets LED to on
                while(state==first_char){
                    Idle();                           //waits for interrupt
                    if(RecvUartChar()==password[0]){  //checks if first character matches
                        state=second_char;            //go to next check state
                    }
                    else{
                        if(CNflag==1){                //checks if PB1 was pressed to go back to start of this state
                            CNflag=0;                 //resets flag
                            IOcheck();                //checks IO
                            if(p1==0){                    //if PB1 was pressed will return back to beginning of state
                                break;                    //returns back to current state
                            }
                        }
                        state=error;                  //sends to error state
                        error_msg=1;                  //if it gets here that means the character was incorrect. sets error message to display character was incorrect
                    }     
                }
                break;
                
            case second_char:
                /*Second locked state checking if the second character is correct.
                 */
                count=0;                              //resets blink counter from previous state
                Disp2String("\n\rCorrect 1st character. Enter 2nd character\n\r");
                delay_misc(500);                      //starts blink timer 500ms(changes on off state every 500ms so 1000ms a blink
                if(RecvUartChar()==password[1]){      //checks if second character is correct
                    state=third_char;                 //go to next state
                    T2CONbits.TON=0;                  //turns off blink timer
                }
                else{
                    if(CNflag==1){                    //checks if PB1 was pressed to go back to start of this state
                        CNflag=0;                     //resets flag
                        IOcheck();                    //checks IO
                        if(p1==0&&error_msg!=2){          //if PB1 was pressed go back to beginning. also makes sure there wasnt a timeout error, else will overwrite the state change
                            state=first_char;              //send back to beginning
                            Disp2String("\rDevice locked\n\r");
                        }
                    }
                    else if(error_msg==2){           //if timed out break to avoid change of error state
                        T2CONbits.TON=0;              //turn off blink timer 
                    }else{
                        state=error;                  //send to error state
                        error_msg=1;                  //if it gets here that means the character was incorrect. sets error message to display character was incorrect
                        T2CONbits.TON=0;              //turn off blink timer 
                    }
                }
                break;
         
            case third_char:
                /*Third locked state checking if the third character is correct.
                 */
                count=0;                             //resets blink counter from previous state
                Disp2String("\n\rCorrect 2nd character. Enter 3rd character\n\r");
                delay_misc(350);                     //starts blink timer 350ms(changes on off state every 350ms so 700ms a blink
                if(RecvUartChar()==password[2]){     //checks if third character is correct
                    state=fourth_char;               //send to next state
                    T2CONbits.TON=0;                 //turns off blink timer
                }
                else{
                    if(CNflag==1){                   //checks if PB1 was pressed to go back to start of this state
                        CNflag=0;                    //resets flag
                        IOcheck();                   //checks IO
                        if(p1==0&&error_msg!=2){         //if PB1 was pressed go back to beginning. needs to make sure it wasnt timed out so the state doesnt get overwritten
                            state=first_char;            //send back to beginning
                            Disp2String("\rDevice locked\n\r");
                        }
                    }
                    else if(error_msg==2){          //if timed out break to avoid change of error state
                        T2CONbits.TON=0;             //turns off blink timer
                    }else{
                        state=error;                 //send to error state
                        error_msg=1;                 //if it gets here that means the character was incorrect. sets error message to display character was incorrect
                        T2CONbits.TON=0;             //turns off blink timer
                    }                        
                }
                break;
                
            case fourth_char:
                /*Fourth locked state checking if the last digit(ADC) is correct.
                 */
                count=0;                         //resets blink counter from previous state
                delay_ADC(50);                   //Delay for ADC. checks every 50ms
                delay_misc(250);                 //starts blink timer 250ms (changes on off state every 250ms so 500ms a blink)
                Disp2String("\n\rEnter Unlock Number\n\r");
                CNflag2=0;                       //resets flag for PB2
                IOcheck();                       //checks IO to reset values before entering ADC loop
                while(state==fourth_char){
                    if(T1Flag==1){               //waits for timer interrupt then activates ADC
                        ADC=do_ADC();            //gets the ADC output
                        T1Flag=0;                //clears flag
                    }   
                    BarGraphDec(ADC);            //displays bar graph and determines the 0-9 digit
                    if(CNflag==1||CNflag2==1){   //checks for either PB1 or PB2 pressed. Either will trigger the need to see which was pressed
                        CNflag=0;                //reset flag
                        CNflag2=0;               //reset flag
                        IOcheck();               //checks IO
                    }
                    if(error_msg==2){            //if timed out break to avoid change of error state
                        break;                   //breaks while loop to get out of current state and go to error
                    }
                    else if(p1==0){              //if PB1 was pressed go back to beginning 
                        state=first_char;        //send back to beginning
                        Disp2String("\rDevice locked\n\r");
                    }
                    else if(p2==0){              //waits until PB2 is pressed
                        
                        if(len_bar==ADCpassword){    //checks to see if the current value from the ADC bar graph matches the fourth value of the password
                            state=unlocked;      //switch to unlocked state
                            Disp2String("\n\r");
                            T1CONbits.TON=0;     //turn off blink timer
                        }
                        else{                    //if password didnt match go to the error state
                            state=error;         //go to error state
                            error_msg=1;         //if it gets here that means the character was incorrect. sets error message to display character was incorrect
                        }
                    }
                }
                break;
            
            case unlocked:
                /*This is the unlocked state. Depending on which PB was pressed will determine the next state. PB1 locks the device. PB2 allows for the user to change passwords.
                 * PB3 allows the user to go to the special state.
                 */
                count=0;                        //reset blink count from previous state
                T2CONbits.TON=0;                //turns off blink timer since it is not used here
                LATBbits.LATB8=0;               //turns off LED
                T2Flag=0;                       //resets 5 second timer flag
                while(state==unlocked){         //waits for one of the PBs to be pressed
                    Idle();                     //waits for interrupt
                    if(CNflag==1||CNflag2==1||CNflag3==1){ //checks for any of the PBs pressed
                        IOcheck();              //Checks IO
                        //resets flags
                        CNflag=0;          
                        CNflag2=0;
                        CNflag3=0;
                        if(p1==0){              //PB1 pressed go back to the beginning
                            Disp2String("Device Locked\n\r");
                            state=first_char;
                        }else if(p2==0){        //PB2 pressed change password
                            Disp2String("Enter a new 3 digit password along with selecting an unlock number with potentiometer\n\r");
                            RecvUart(receive_buffer, BUF_SIZE);   //gets new first 3 characters of the password
                            if(CNflag==1){
                                CNflag=0;
                                IOcheck();
                            }
                            if(p1!=0){
                                for (uint8_t i=0; i<4; i++)
                                {
                                    password[i]=receive_buffer[i];   //copys value entered into password
                                }
                                delay_ADC(50);                  //starts ADC timer
                                while(1){                        //while loop for new ADC password (4th character). Will stay here until new password has been chosen
                                    if(T1Flag==1){               //waits for timer to finish then activates ADC
                                        ADC=do_ADC();            //gets the ADC output
                                        T1Flag=0;                //clears flag
                                    }  
                                    Disp2String("\r");           //returns to start of line
                                    BarGraphDec(ADC);            //displays ADC bar graph
                                    if(CNflag==1){               //makes sure the user doesnt try to lock it without setting new password
                                        CNflag=0;
                                        Disp2String("\rCan't lock when changing password\n\r");
                                    }
                                    if(CNflag2==1){              //checks for if PB2 was pressed
                                        CNflag2=0;               //resets PB2 flag
                                        IOcheck();               //check IO
                                        if(p2==0){               //waits for PB2 to be pressed and then sets new ADC password
                                            ADCpassword=len_bar;     //sets new ADC password
                                            Disp2String("\n\r");     //send to the next line
                                            break;                   //break out of while loop
                                        }
                                    } 
                                }
                                Disp2String("Change Successful\n\r");
                                delay_misc(5000);                  //starts 5 second timer to return back to locked state
                                while(T2Flag!=1){                  //makes sure nothing will stop the 5 second timer 
                                    Idle();                        //waits for interrupt
                                    if(T2Flag==1){                 //once the timer interrupt has happened send back to beginning
                                        state=first_char;          //goes back to beginning
                                    }
                                }
                            }   
                            else{
                                Disp2String("Returning to locked state with same password\n\r");
                                state=first_char;
                            }
                        }else if(p3==0){                    //PB3 pressed go to the special state
                            state=special;                  //go to special state
                        }
                    }
                }
                break;

            case error:
                /*Error state. If the password was incorrect or it timed out, the state will be sent here
                 */
                count=0;                                   //resets blink counter from previous state
                if(error_msg==1){                          //this is for incorrect password
                    Disp2String("\n\rIncorrect Password. Please try again\n\r");
                }
                else if(error_msg==2){                     //this is for timed out
                    T2CONbits.TON=0;                       //turns off the blink timer
                    Disp2String("\n\rTimed out. Please try again\n\r");
                }
                while(state==error){                       //keeps it in error state until PB2 is pressed
                    Idle();                                //waits for interrupt
                    if(CNflag2==1){                        //checks for PB2 pressed
                        CNflag2=0;                         //resets flag
                        IOcheck();                         //checks IO
                        if(p2==0){                         //if PB2 was pressed send back to beginning
                            state=first_char;              //sends back to beginning
                            error_msg=0;                   //resets error message
                        }
                    }
                }
                break;
                
            case special:
                /*Special state. see below Disp2String for description.
                 */
                count=0;                        //reset blink count from previous state
                LATBbits.LATB8=0;               //turns off LED
                CNflag3=0;                      //reset PB3 flag
                Disp2String("Welcome to the Special Mode! Press PB2 to set the max timer and then press PB2 again to confirm\n\r");
                Disp2String("After the special timer is set, press PB1 to pause/start or hold PB1 to reset the special timer.\n\r");
                Disp2String("Press PB3 to return to lock device\n\r");
                while(state==special){
                    Idle();                     //waits for interrupt
                    if(CNflag2==1||CNflag3==1){ //checks for PB1 or PB2 pressed to decide where to go next
                        //reset flags
                        CNflag2=0;
                        CNflag3=0;
                        IOcheck();              //checks IO
                        if(p2==0){              //if PB2 was pressed send to the state where the timer is started
                            state=special_timer;
                            delay_ADC(50);      //start ADC timer
                            Disp2String("Press PB2 to set the timer max\n\r");
                            while(1){
                                if(T1Flag==1){               //waits for timer to finish then activates ADC
                                    ADC=do_ADC();            //gets the ADC output
                                    T1Flag=0;                //clears flag
                                }  
                                ADCDec(ADC);
                                Disp2String(" s");
                                if(CNflag2==1||CNflag3==1){              //checks for if PB2 was pressed
                                    CNflag2=0;               //resets PB2 flag
                                    CNflag3=0;               //resets PB3 flag
                                    IOcheck();               //check IO
                                    if(p2==0){               //waits for PB2 to be pressed and then sets new ADC password
                                        ADC_timer_val=len_bar;     //sets new ADC password
                                        Disp2String("\n\rTimer has been set\n\r");
                                        break;                   //break out of while loop
                                    }else if(p3==0){         //checks if p3 was pressed to return back to the beginning
                                        state=first_char;    //goes back to the beginning
                                        Disp2String("Exiting Special State\n\r");
                                        break;               //break out of while loop
                                    }
                                } 
                            }
                        }else if(p3==0){        //if PB3 was pressed send back to the locked state
                            state=first_char;
                        }
                    }
                }  
                break;
                
            case special_timer:
                /*This is where the timer gets incremented and displays to the Uart. Timer will complete when reaches value chosen by the user. if PB3 is pressed return to locked state. if PB1 is pressed go to toggle state
                 */
                XmitUART2('\r', 1);             //send to the beginning of the line
                delay_misc(1000);               //starts the second timer
                //resets flags
                CNflag=0;                       
                CNflag2=0;
                CNflag3=0;
                while(state==special_timer){
                    if (seconds > ADC_timer_val-1) //checks to see if it exceeds the timer max. subtracting 1 to make sure it completes at the desired time
                    {
                        Disp2String("\rTimer Completed. Please press PB2 to reset");
                        //makes sure all the timers are off
                        T1CONbits.TON=0;  
                        T2CONbits.TON=0;
                        T3CONbits.TON=0;  
                        Idle();                 //waits for interrupt
                    }else{
                        // Display seconds increment when pressing PB2
                        Disp2Dec(seconds);      //prints "seconds s"
                        Disp2String(" s");
                        XmitUART2('\r', 1);
                    }
                    if(CNflag==1||CNflag2==1||CNflag3==1){  //checks if any of the PBs have been pressed
                        //resets flags
                        
                        CNflag2=0;
                        CNflag3=0;
                        IOcheck();              //checks IO
                        if(p3==0){              //if PB3 was pressed go back to the locked state
                            state = first_char; //goes back to locked state
                            Disp2String("Exiting Special State\n\r");
                        }
                        else if(p1==0){         //if PB1 was pressed go to toggle state to pause or start
                            state=special_toggle; //goes to toggle state
                        }
                        else if (p2==0&&seconds>ADC_timer_val-1){ //resets the timer back to zero once the timer has completed
                            XmitUART2('\r', 1);
                            Disp2String("                                                   ");  //clears current line
                            seconds=0;
                            break;
                        }
                    }
                    
                }
                break;
                
            case special_reset_timer:
                /*state used to reset timer when PB1 was held down for 5 seconds
                 */
                XmitUART2('\r', 1);
                Disp2String("                                         ");  //clears current line
                Disp2String("\r 00 s\r"); // Display reseted timer
                seconds = 0; // Reset seconds
                start_pause = 0; // Initialize timer again (paused state)
                while(state==special_reset_timer){
                    Idle();                           //Wait for interrupt
                    if(CNflag2==1||CNflag3==1){       //checks for PB1 or PB2 pressed
                        CNflag2=0;                     //clear flag
                        CNflag3=0;                     //clear flag
                        IOcheck();                     //checks IO
                    }
                    if(p2==0){                     //if PB2 was pressed switch back to the 
                        state=special_timer;       //switch states 
                    }
                    if(p3==0){                     //if PB3 was pressed go back to the locked state
                        state = first_char;        //goes back to locked state
                        Disp2String("Exiting Special State\n\r");
                    }
                }
                break;
                
            case special_toggle:
                /*state used for toggling the pause and start state for the special timer
                 */
                while(state == special_toggle){
                    if(CNflag==1){       //checks if PB1 was pressed. will be active from previous state(special tiemr) to allow it to check immediately 
                        CNflag=0;        //resets the flag now to make sure it runs through this once 
                        TogglingCheck(); //see if user is pressing or holding PB1
                        T2CONbits.TON=0; //turns off seconds timer
                    } 
                    if(toggle==1){       //if toggle is 1 breaks out of this to make sure the timer doesnt get turned back on
                        break;           
                    }
                    if(start_pause == 1) //if start
                    {
                        state=special_timer;
                        T2CONbits.TON=1;
                    }
                    else if(start_pause == 0)//if paused
                    {
                        //turns off all timers
                        T1CONbits.TON=0;  
                        T2CONbits.TON=0;
                        T3CONbits.TON=0; 
                        Idle();
                    }
                    if(CNflag3==1){     //if PB3 is pressed 
                        CNflag3=0;      //reset flag
                        IOcheck();      //check IO
                        if(p3==0){      //if PB3 is pressed go back to the locked state
                            state = first_char;//goes back to locked state
                            Disp2String("Exiting Special State\n\r");
                        }
                    }
                }
                break;
                
            default:
                break;
        } 
    }
    return 0;
}

void __attribute__((interrupt, no_auto_psv)) _CNInterrupt(void)
{   
    if(PB1==0){                               //PB1 press will set flag
        CNflag=1;
    }
    if(PB2==0){                               //PB2 press will set flag
        CNflag2=1;
    }
    if(PB3==0){                               //PB3 press will set flag
        CNflag3=1;
    }
    IFS1bits.CNIF = 0; // clear IF flag
    return;
}

void BarGraphDec(uint16_t ADC_int) //Decimal bar graph function
{
    uint16_t len = 10;             //bar is a 50 characters long

    len_bar = (unsigned int)(ADC_int * len / 1024); //takes the ratio of the ADC output to the ADC max value and then finds out how many '-' long it will be
    
    XmitUART2('-', len_bar);       //Width of bar
    XmitUART2('_', (len - len_bar-1)); //fills the remaining line with '_' to show blank
    Disp2Dec(len_bar);             //adds Decimal value at the end of the bar
    Disp2String("\r");             //return to start of line

    return;
}

void ADCDec(uint16_t ADC_int) //ADC special function
{
    uint16_t len = 60;             //max 50 characters long

    len_bar = (unsigned int)(ADC_int * len / 1024); //takes the ratio of the ADC output to the ADC max value and then finds out how many '-' long it will be
    Disp2String("\r");             //return to start of line
    Disp2Dec(len_bar);             //adds Decimal value at the end of the bar
    

    return;
}

void TogglingCheck(void) 
{
    reset=0;                       //resets reset to make sure a previous call of the timer didnt set reset to 1
    toggle=0;                      //sets toggle to 0 to allow for it to toggle states once it exits this function
    delay_ms(5000);                //starts a 5 second timer. if it reaches 5 seconds will set reset to 1 allowing the timer to be reset
    while(PB1==0){                 //makes sure it stays here until the button has been released
        if(reset==1){              //if the timer has finished while holding down PB1 it will set reset to 1 and send it to the reset state
            state=special_reset_timer; //goes to reset state
        }
    }
    if(reset==1){                  //if it did reach 5 seconds sets toggle to 1 to break out of the special timer state once this returns
        toggle=1;
    }else{
        if (start_pause == 0){ // Toggle each time PB1 is pressed for less than 5s (one for start, one for pause)
            start_pause = 1;
        }
        else{
            start_pause = 0;   
        }
    }

    return;
}

void IOcheck(void) {    //used to check IO after CN interrupt
    //turns off all ISR enables to ensure proper de-bounce 
    IEC1bits.CNIE = 0;
    IEC0bits.T2IE = 0;
    IEC0bits.T1IE = 0;
    IEC1bits.U2RXIE = 0;	
    delay_ms(50);                        //delay that cant be interrupted by PB press for proper de-bounce
    //read all values
    p1=PB1;
    p2=PB2;
    p3=PB3;
    //turns back on all ISR enables
    IEC1bits.U2RXIE = 1;
    IEC0bits.T2IE = 1;
    IEC1bits.CNIE = 1;
    IEC0bits.T1IE = 1;
}