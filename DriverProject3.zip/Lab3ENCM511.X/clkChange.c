/*
 * File:   clkChange.c
 * Author: Sean, Ryeen, Aarushi
 *
 * Created on October 15, 2023, 9:29 PM
 */

#include "xc.h"
#include "clkChange.h"

void newClk (unsigned int clkval) {
    char COSCNOSC;
    if (clkval == 8)
    {
        COSCNOSC= 0x00;
    }
    else if (clkval == 500)
    {
        COSCNOSC= 0x66;
    }
    else if (clkval == 32)
    {
        COSCNOSC= 0x55;
    }
    else
    {
        COSCNOSC= 0x55;
    }
    
    SRbits.IPL = 7;
    CLKDIVbits.RCDIV = 0;
    __builtin_write_OSCCONH(COSCNOSC);
    __builtin_write_OSCCONL(0x01);
    OSCCONbits.OSWEN=1;
    while(OSCCONbits.OSWEN==1)
    {
    }
    SRbits.IPL = 0;
}
