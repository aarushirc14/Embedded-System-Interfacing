/*
 * File:   IOCheck.c
 * Author: Sean, Ryeen, Aarushi
 *
 * Created on October 10, 2023, 9:22 AM
 */

#include "xc.h"
#include "clkChange.h"

void IOcheck(void) {
    
    //read all values to allow for consecutive button pushing
    uint8_t ra2 =PORTAbits.RA2;
    uint8_t ra4 =PORTAbits.RA4;
    uint8_t rb4 =PORTBbits.RB4;
    uint8_t state =ra2+ra4;
    
    if((state==0)){                //Checks to see if both PB1 and PB2 are pressed
        LATBbits.LATB8 ^= 1;       //flips the bit on and off
        delay_ms(1);               //1 ms
    }else{
        if(ra2==0){
            LATBbits.LATB8 ^= 1;
            delay_ms(500);         //0.5 seconds
        }else if(ra4==0){ 
            LATBbits.LATB8 ^= 1;
            delay_ms(1000);        //1 seconds
        }else if(rb4 == 0){ 
            LATBbits.LATB8 ^= 1;
            delay_ms(5000);        //5 seconds
        }else{
            LATBbits.LATB8 = 0;    //If nothing is pressed it will force the LED off
        }
    }   
    return;
}

void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void){
    IFS0bits.T2IF=0;              //clears the  flag
    T2CONbits.TON=0;              //Turns off timer
}

void delay_ms(unsigned int (time_ms)){
    TMR2=0;                      //resets timer
    PR2= time_ms *(4);           //(500000/(2*64*1000))=3.9025~=4
    T2CONbits.TON=1;             //Turns on timer
    Idle();                      //makes main wait for TMR2==PR2 
    return;
}
