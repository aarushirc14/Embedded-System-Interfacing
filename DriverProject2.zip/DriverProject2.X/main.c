/*
 * File:   main.c
 * Authors: Sean Schmalzl, Ryeen Khondokar, Aarushi Roychoudhury (Group 14) 
 *
 * Created on October 3, 2023, 11:29 AM
 */


#include "xc.h"
#include <stdio.h>
#include <stdlib.h>

void main(void) {
    
    AD1PCFG = 0XFFFF; // Sets all analog ports to digital IO
     
    //Push Buttons as Inputs (PB1, PB2, PB3
    TRISAbits.TRISA2 = 1; // RA2 Port, PB1
    TRISBbits.TRISB4 = 1; // RB4 Port, PB2
    TRISAbits.TRISA4 = 1; // RA4 Port, PB3
    
    //Pull Up for Inputs
    CNPU2bits.CN30PUE = 1; // RA2, PB1
    CNPU1bits.CN1PUE = 1;  // RB4, PB2
    CNPU1bits.CN0PUE = 1;  // RA4, PB3
    
    // LED Output
    TRISBbits.TRISB8 = 0; //RB8 
    
    uint32_t count = 0; //counter for delays
    
    while (1)
    {
     
        
       uint8_t PBsPressed = PORTAbits.RA2 + PORTAbits.RA4 + PORTBbits.RB4; // Counts how many Push Buttons are being pressed (0 = All, 1 = Two, 2 = One, 3 = None)
        
        if (PBsPressed == 3) // No Push Buttons are pressed
        {
            LATBbits.LATB8 = 0; // LED OFF
        }
        
        else if (PBsPressed <=1) // While at least 2 Push Buttons are pressed
        {
            LATBbits.LATB8 = 1; // LED ON without blinking          
        }
        
        else if (PORTAbits.RA2 == 0) // While PB1 is pressed LED blinks at 0.5 s interval
        {
            LATBbits.LATB8 = 1;  // LED ON
            
            while(count <100000){
               count++;
           }
           count = 0;
         
          LATBbits.LATB8 = 0;  // LED OFF
  
            
            while(count <100000){
                count++;
            }
            count = 0;
        }
        
        else if (PORTBbits.RB4 == 0)  // While PB2 is pressed LED blinks at 1 s interval
        {             
            LATBbits.LATB8 = 1;  // LED ON
            
             while(count <170000){
                count++;
            }
            count = 0;
           
            LATBbits.LATB8 = 0;  // LED OFF
            
             while(count <170000){
                count++;
            }
            count = 0;
                                        
        }
            
        else if (PORTAbits.RA4 == 0) // While PB3 is pressed LED blinks at 2 s interval
        {
            LATBbits.LATB8 = 1;  // LED ON
           
             while(count <250000){
                count++;
            }
            count = 0;
            
            LATBbits.LATB8 = 0;  // LED OFF
           
             while(count <250000){
                count++;
            }
            count = 0;
        }

                          
    
   }
    
    return;
}
